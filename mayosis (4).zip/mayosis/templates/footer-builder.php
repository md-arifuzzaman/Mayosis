<?php
 if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
} ?>
 <footer class="mayosis-footer-builder">
	
	


		     <?php mayosis_footer_builder(); ?>
	
           
	

	
</footer>