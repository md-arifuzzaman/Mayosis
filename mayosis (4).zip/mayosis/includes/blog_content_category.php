<?php
defined('ABSPATH') or die();

?>

 <span class="toolspan"><?php esc_html_e("in","mayosis"); ?></span> <span class="blog--layout--contents"><?php mayosis_category_list(); ?></span>